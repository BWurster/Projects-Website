import pyaudio
import struct
import numpy as np
import matplotlib.pyplot as plt
from scipy.fftpack import fft
import pandas as pd
import serial
import time


class AudioLights:
    def __init__(self):
        self.CHUNK = 1024 * 4
        self.FORMAT = pyaudio.paInt16
        self.CHANNELS = 1
        self.RATE = 44100

        self.UPPER_FREQ_BOUND = 225
        self.LOWER_FREQ_BOUND = 80

        self.p = pyaudio.PyAudio()

        self.stream = self.p.open(format=self.FORMAT,
                        channels=self.CHANNELS,
                        rate=self.RATE,
                        input=True,
                        input_device_index=1,
                        frames_per_buffer=self.CHUNK)

        self.arduinoData = serial.Serial('COM3', 9600)
        self.trueFreqAdjustment = np.linspace(0, self.RATE, self.CHUNK)
        self.data_np = None

        self.mainFreq = 0
        self.mainFreq2 = 0
        self.freqChange = 0
        
        self.R = 0
        self.G = 0
        self.B = 0

        while True:
            self.sampleAudio()

            if(np.max(self.data_np) < 10):
                self.writeRGB(0, 0, 0)
                mainFreq = 0
                mainFreq2 = 0
            else:
                self.mainFreq = pd.Series.idxmax(self.signals_adjustedRange)
                self.freqChange = self.mainFreq2 - self.mainFreq
                self.mainFreq2 = self.mainFreq

                if (self.mainFreq < self.LOWER_FREQ_BOUND):
                    self.mainFreq = self.LOWER_FREQ_BOUND
                elif (self.mainFreq > self.UPPER_FREQ_BOUND):
                    self.mainFreq = self.UPPER_FREQ_BOUND

                # self.mapRedBlue()
                self.mapPopColorWheel()


    def writeRGB(self, R, G, B):
        strR = str(int(R))
        strG = str(int(G))
        strB = str(int(B))
        while (len(strR) < 3):
            strR = "0" + strR
        while (len(strG) < 3):
            strG = "0" + strG
        while (len(strB) < 3):
            strB = "0" + strB
        dataString = strR + strG + strB
        print(dataString)
        self.arduinoData.write(bytes(dataString, 'utf-8'))

    def sampleAudio(self):
        data = self.stream.read(self.CHUNK)
        data_int = struct.unpack(str(2 *self.CHUNK) + 'B', data)

        self.data_np = np.array(data_int, dtype='b')[::2] # Array of samples. Important for telling if music is playing.

        data_fft =  np.abs(fft(data_int)[0:self.CHUNK]) / (128 * self.CHUNK)
        self.signals = pd.Series(data_fft, index=self.trueFreqAdjustment) # Series of signals indexed by their freqency.

        self.signals_adjustedRange = self.signals.loc[30:300] # Signals in a specific range for niche purposes.
    
    def mapRedBlue(self):
        high = self.UPPER_FREQ_BOUND
        low = self.LOWER_FREQ_BOUND
        G = 0
        midpoint = (high - low) / 2 + low
        if (self.mainFreq > midpoint):
            B = 255
            R = 255 / (midpoint - high) * (self.mainFreq - high)
        else:
            R = 255
            B = 255 / (midpoint - low) * (self.mainFreq - low)
        self.writeRGB(R, G, B)

    def mapPopColorWheel(self):
        WHEEL_TICK = 10

        if (self.R != 255 and self.G != 255 and self.B != 255):
            self.R = 255

        # red to yellow
        if (self.R == 255 and self.G < 255 and self.B == 0):
            self.G = self.G + WHEEL_TICK
            if (self.G > 255):
                self.G = 255
        # yellow to green
        elif (self.R > 0 and self.G == 255 and self.B == 0):
            self.R = self.R - WHEEL_TICK
            if (self.R < 0):
                self.R = 0
        # green to cyan
        elif (self.G == 255 and self.R == 0 and self.B < 255):
            self.B = self.B + WHEEL_TICK
            if (self.B > 255):
                self.B = 255
        # cyan to blue
        elif (self.G > 0 and self.B == 255 and self.R == 0):
            self.G = self.G - WHEEL_TICK
            if (self.G < 0):
                self.G = 0
        # blue to magenta
        elif (self.B == 255 and self.G == 0 and self.R < 255):
            self.R = self.R + WHEEL_TICK
            if (self.R > 255):
                self.R = 255
        # magenta to red
        elif (self.B > 0 and self.R == 255 and self.G == 0):
            self.B = self.B - WHEEL_TICK
            if (self.B < 0):
                self.B = 0

        brightness = 1 / (self.UPPER_FREQ_BOUND - self.LOWER_FREQ_BOUND) * (self.mainFreq - self.LOWER_FREQ_BOUND)

        tempR = brightness * self.R
        tempG = brightness * self.G
        tempB = brightness * self.B
        self.writeRGB(tempR, tempG, tempB)

if __name__ == "__main__":
    AudioLights()
