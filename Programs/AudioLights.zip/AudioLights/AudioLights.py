import pyaudio
import struct
import numpy as np
import matplotlib.pyplot as plt
from scipy.fftpack import fft
import pandas as pd
import serial
import time


class AudioLights:
    def __init__(self):
        self.CHUNK = 1024 * 4
        self.FORMAT = pyaudio.paInt16
        self.CHANNELS = 1
        self.RATE = 44100

        self.upperFreqBound = 0
        self.lowerFreqBound = 1000

        self.p = pyaudio.PyAudio()

        self.stream = self.p.open(format=self.FORMAT,
                        channels=self.CHANNELS,
                        rate=self.RATE,
                        input=True,
                        input_device_index=1,
                        frames_per_buffer=self.CHUNK)

        PORT = 'COM4'
        self.arduinoData = serial.Serial(PORT, 9600)
        self.trueFreqAdjustment = np.linspace(0, self.RATE, self.CHUNK)
        self.data_np = None

        self.mainFreq = 0
        
        self.R = 0
        self.G = 0
        self.B = 0

        while (self.upperFreqBound <= self.lowerFreqBound):
            self.sampleAudio()

        while True:
            self.sampleAudio()

            self.mapRedBlue()
            # self.mapPopColorWheel()

    def writeRGB(self, R, G, B):
        strR = str(int(R))
        strG = str(int(G))
        strB = str(int(B))
        while (len(strR) < 3):
            strR = "0" + strR
        while (len(strG) < 3):
            strG = "0" + strG
        while (len(strB) < 3):
            strB = "0" + strB
        dataString = strR + strG + strB
        self.arduinoData.write(bytes(dataString, 'utf-8'))

    def sampleAudio(self):
        data = self.stream.read(self.CHUNK)
        data_int = struct.unpack(str(2 *self.CHUNK) + 'B', data)

        self.data_np = np.array(data_int, dtype='b')[::2] # Array of samples. Important for telling if music is playing.

        data_fft =  np.abs(fft(data_int)[0:self.CHUNK]) / (128 * self.CHUNK)
        self.signals = pd.Series(data_fft, index=self.trueFreqAdjustment) # Series of signals indexed by their freqency.

        self.signals_adjustedRange = self.signals.loc[30:500] # Signals in a specific range for niche purposes.

        if(np.max(self.data_np) < 10):
                self.writeRGB(0, 0, 0)
                mainFreq = 0
        else:
            self.mainFreq = pd.Series.idxmax(self.signals_adjustedRange)

            self.expandRange()
            self.shrinkRange()
            self.modifyMainFreq()
        print(self.upperFreqBound, self.lowerFreqBound)
    
    def expandRange(self):
        if(self.mainFreq < self.lowerFreqBound):
            self.lowerFreqBound = self.mainFreq
        if(self.mainFreq > self.upperFreqBound):
            self.upperFreqBound = self.mainFreq          

    def modifyMainFreq(self):
        # adjusts frequency to be in range
        if (self.mainFreq < self.lowerFreqBound):
            self.mainFreq = self.lowerFreqBound
        elif (self.mainFreq > self.upperFreqBound):
            self.mainFreq = self.upperFreqBound

    def shrinkRange(self):
        self.lowerFreqBound = self.lowerFreqBound + 0.1 * (self.upperFreqBound - self.lowerFreqBound)
        self.upperFreqBound = self.upperFreqBound - 0.1 * (self.upperFreqBound - self.lowerFreqBound)

    def mapRedBlue(self):
        high = self.upperFreqBound
        low = self.lowerFreqBound
        midpoint = (high - low) / 2 + low
        print(high, midpoint, low, sep=', ')
        if (self.mainFreq > midpoint):
            B = 255
            R = 255 / (midpoint - high) * (self.mainFreq - high)
        else:
            R = 255
            B = 255 / (midpoint - low) * (self.mainFreq - low)
        self.writeRGB(R, 0, B)

    def mapPopColorWheel(self):
        WHEEL_TICK = 10

        if (self.R != 255 and self.G != 255 and self.B != 255):
            self.R = 255

        # red to yellow
        if (self.R == 255 and self.G < 255 and self.B == 0):
            self.G = self.G + WHEEL_TICK
            if (self.G > 255):
                self.G = 255
        # yellow to green
        elif (self.R > 0 and self.G == 255 and self.B == 0):
            self.R = self.R - WHEEL_TICK
            if (self.R < 0):
                self.R = 0
        # green to cyan
        elif (self.G == 255 and self.R == 0 and self.B < 255):
            self.B = self.B + WHEEL_TICK
            if (self.B > 255):
                self.B = 255
        # cyan to blue
        elif (self.G > 0 and self.B == 255 and self.R == 0):
            self.G = self.G - WHEEL_TICK
            if (self.G < 0):
                self.G = 0
        # blue to magenta
        elif (self.B == 255 and self.G == 0 and self.R < 255):
            self.R = self.R + WHEEL_TICK
            if (self.R > 255):
                self.R = 255
        # magenta to red
        elif (self.B > 0 and self.R == 255 and self.G == 0):
            self.B = self.B - WHEEL_TICK
            if (self.B < 0):
                self.B = 0

        brightness = 1 / (self.upperFreqBound - self.lowerFreqBound) * (self.mainFreq - self.lowerFreqBound)

        tempR = brightness * self.R
        tempG = brightness * self.G
        tempB = brightness * self.B
        self.writeRGB(tempR, tempG, tempB)

if __name__ == "__main__":
    AudioLights()
