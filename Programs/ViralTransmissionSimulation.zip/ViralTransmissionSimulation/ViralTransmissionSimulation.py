import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn; seaborn.set()

numPoints = 100

xPos = np.random.random(numPoints)
yPos = np.random.random(numPoints)

state = np.zeros(numPoints) # 0 ==> healthy(green), 1 ==> infected(red), 2 ==> recovered(blue), might add 3 ==> dead(black)
state[0] = 1 # <== this is the moron who ate a bat

daysInfected = np.zeros(numPoints)

patientData = pd.DataFrame({'X': xPos, 'Y': yPos, 'state': state, 'daysInfected': daysInfected})
print(patientData)

xDist = xPos[:, np.newaxis] - xPos[np.newaxis, :]
yDist = yPos[:, np.newaxis] - yPos[np.newaxis, :]
dist_sq = (xDist ** 2) + (yDist ** 2)

infectChance = dist_sq * 10  # this is a variable to experiment with
recoveryTime = 5 #days, this is the amount of time to transition between infected and healthy

plt.scatter(patientData.loc[:, 'X'], patientData.loc[:,'Y'], s=10, color="green")
plt.scatter(patientData.loc[0, 'X'], patientData.loc[0,'Y'], s=10, color="red")

day = 0
print('After ', day, ' day(s):')
plt.show

while True: # add break statement for all 'state' = 0 for dead disease
    # input('<Enter> to Continue')
    plt.show()
    
    infectorIndices = []
    infecteeIndices = []

    for i in range(numPoints):
        # check to see if patient becomes non-contagious
        if (patientData.loc[i, 'state'] == 1):
            if patientData.loc[i, 'daysInfected'] >= recoveryTime:
                patientData.loc[i, 'state'] = 2.0
                
        # check for patient is still contagious       
        if (patientData.loc[i, 'state'] == 1):
            # by chance infects others based on proximity
            for j in range(numPoints):
                randNum = np.random.random(1)
                if (randNum > infectChance[i, j]) and (patientData.loc[j, 'state'] == 0):
                    infectorIndices.append(i)
                    infecteeIndices.append(j)
                    
            # increases days contagious
            patientData.loc[i, 'daysInfected'] = patientData.loc[i, 'daysInfected'] + 1
    
    # applies infection to those in infectionIndices
    for i in range(len(infecteeIndices)):
        patientData.loc[infecteeIndices[i], 'state'] = 1;
        plt.plot([patientData.loc[infecteeIndices[i], 'X'], patientData.loc[infectorIndices[i], 'X']], [patientData.loc[infecteeIndices[i], 'Y'], patientData.loc[infectorIndices[i], 'Y']], color="red")
    
    for i in range(numPoints):
        if patientData.loc[i, 'state'] == 0:
            plt.scatter(patientData.loc[i, 'X'], patientData.loc[i,'Y'], s=10, color="green")
        elif patientData.loc[i, 'state'] == 1:
            plt.scatter(patientData.loc[i, 'X'], patientData.loc[i,'Y'], s=10, color="red")
        elif patientData.loc[i, 'state'] == 2:
            plt.scatter(patientData.loc[i, 'X'], patientData.loc[i,'Y'], s=10, color="blue")
            
    print('After ', day, ' day(s):')
    day += 1
    print(patientData)
    plt.show()

    if not np.any(patientData['state'] == 1):
        break
    if (day > 20):
        break

input('<Enter> to Close')